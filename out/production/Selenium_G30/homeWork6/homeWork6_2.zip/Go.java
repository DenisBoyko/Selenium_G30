package homeWork6;

public interface Go {
    void go();
}
