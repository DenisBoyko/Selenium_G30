package homeWork6;

public interface EatFish {
    void eatFish();
}
