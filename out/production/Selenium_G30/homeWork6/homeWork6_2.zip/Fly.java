package homeWork6;

public interface Fly {
    void fly();
}
