package homeWork6;

public interface HideHead {
    void hideHead();
}
